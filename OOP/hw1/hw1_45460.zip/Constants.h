//
// Created by yasen on 3/20/18.
//

#ifndef HW1_CONSTANTS_H
#define HW1_CONSTANTS_H

static const unsigned systemWalletId = ~0;
static const short unsigned FMICoinExchangeRates = 375;
static const char* WALLETS_DB = "wallets.dat";
static const char* TRANSACTIONS_DB = "transactions.dat";
static const char* ORDER_DB = "orders.dat";


#endif //HW1_CONSTANTS_H
