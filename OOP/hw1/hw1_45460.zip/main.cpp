#include "Helpers.h"

int main() {
    start();
    return 0;
}