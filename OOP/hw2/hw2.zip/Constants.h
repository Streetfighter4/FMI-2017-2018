//
// Created by yasen on 4/3/18.
//

#ifndef HM2_CONSTANTS_H
#define HM2_CONSTANTS_H

static const char* headingSymbol = "# ";
static const char italicSymbol = '*';
static const char* boldSymbol = "**";
static const char* extentionMD = ".md";
static const size_t lenghtOfLine = 1024;

#endif //HM2_CONSTANTS_H
