//
// Created by yasen on 4/20/19.
//

#include "Box.h"

Box::Box() : width(0), height(0), depth(0) {}

Box::Box(size_t newWidth, size_t newHeight, size_t newDepth) : width(newWidth), height(newHeight), depth(newDepth){}
